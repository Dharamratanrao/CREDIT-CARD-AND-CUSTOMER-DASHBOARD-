# Credit-Card-Customer-and-Transaction-Dashboard
🚀 Thrilled to Unveil My Latest Power BI Project: Credit Card Operations Dashboard! 🚀 I recently developed a comprehensive weekly dashboard using Power BI that delivers real-time insights into key performance metrics and trends for credit card operations. 
